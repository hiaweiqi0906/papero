module.exports ={
    MongoURI: 'mongodb+srv://admin-weiqi:test1234@cluster0.iowct.mongodb.net/test?retryWrites=true&w=majority',
    mailchimpID: 'test123:test123'
}